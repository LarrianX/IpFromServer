"""
Данный модуль предоставляет две функции: авторизация на электронном дневнике "elschool", а также
парсер дз и группировка его по дням.


Использование:



"""
import requests
from bs4 import BeautifulSoup
import datetime
from config import elschool_config
login = elschool_config["login"]
password = elschool_config["password"]

url = "https://elschool.ru/users/diaries/details?rooId=36&instituteId=1898&departmentId=261827&pupilId=1789450"
week = int(datetime.date.today().strftime('%W')) + 2
url_next = f"https://elschool.ru/users/diaries/details?RooId=36&InstituteId=1898&DepartmentId=261827&PupilId=1789450&Year={datetime.date.today().strftime('%Y')}&Week={week}&log=False"

def auth(login, password, url, session=None):
    s = False
    if session == 1:
        s = True
        session = None
    if not session:
        session = requests.Session()
        session.post('https://elschool.ru/logon/index', {
            'login': login,
            'password': password,
        })

    response = session.get(url)

    
    if s:
        to_return = (response.text, session)
    else:
        to_return = response.text

    return to_return
    

def pars_les(soup):
    all_les = soup.findAll(class_='flex-grow-1')

    count = 0
    for i in all_les:
        if "1." in i.text:
            count += 1

    return list(map(lambda x: x.text, all_les)), count

def pars_dz(soup):
    all_dz = soup.findAll(class_='diary__homework-text')

    return list(map(lambda x: x.text, all_dz))

def pars(page):
    soup = BeautifulSoup(page, "html.parser")

    les, count = pars_les(soup)
    dz = pars_dz(soup)

    all_lessons = []
    for les_, dz_ in zip(les, dz):
        all_lessons.append([les_, dz_])

    all_lessons = pars_split(all_lessons)
    
    return all_lessons

def pars_split(all_lessons):
    count = 0
    parsed = {}
    skip = False

    for i in all_lessons:
        if i[0][0] == '1' and not skip:
            count += 1
            parsed[count] = []
        if i[0][0] == '0':
            skip = True
            count += 1
            parsed[count] = []
        else:
            skip = False
        parsed[count].append([i[0], i[1]])

    return parsed

def out(all_lessons, data, day, markdown=False):
    days_of_week = ['понедельник', 'вторник', 'среду', 'четверг', 'пятницу']

    
    output = f"Расписание на *{days_of_week[day-1]} {data}*:\n"

    for i in all_lessons[day]:
        if "Физическая культура" in i[0]:
            output += i[0][0] + f". Физ-ра\n"
        else:
            output += f"{i[0]}" + (f" — *{i[1]}*\n" if i[1] else "\n")
        
    # Format
    if not markdown:
        output = output.replace("*", "")

    return output

def data_choose(weekday, next=False):
    today = datetime.date.today()
    today_weekday = today.weekday() + 1
    day = datetime.date.today() # Будем отталкиваться от сегодня

    if weekday != today_weekday:
        if weekday < today_weekday:
            day -= datetime.timedelta(days=(today_weekday - weekday))
        else:
            day += datetime.timedelta(days=(weekday - today_weekday))

    if next:
        day += datetime.timedelta(days=7)
    return day

def auto_parse_les(all_lessons, all_lessons_next, day: int, next=False, markdown=False):
    if day == -1:
        tomorrow = datetime.date.today() + datetime.timedelta(days=1)
        day = tomorrow.weekday() + 1
        if day > 5:
            tomorrow += datetime.timedelta(days=8-day)
            next = True
            day = 1
        if next:
            tomorrow += datetime.timedelta(days=7)
        data = tomorrow.strftime('%d.%m')
    else:
        data = data_choose(day, next=next)

    if day > 7 or type(all_lessons) != dict or type(all_lessons_next) != dict:
        return "Ошибка: неверно введённые данные."

    return out(all_lessons_next if next else all_lessons, data, day, markdown=markdown)
        
def init():
    page, session = auth(login, password, url, session=1)
    all_lessons = pars(page)
    all_lessons_next = pars(auth(login, password, url_next, session=session))
    return all_lessons, all_lessons_next

def main():
    print(init()[0])
    # print(auto_parse_les(*init(), -1))
    

if __name__ == "__main__":
    main()