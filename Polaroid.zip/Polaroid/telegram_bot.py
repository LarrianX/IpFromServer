import asyncio
import logging
import datetime
import gpt_api as gpt
import os
from aiogram import Bot, Dispatcher, types
from elschool_api import *
from config import telegram_config

class Telegram:

    logging.basicConfig(level=logging.INFO)
    dp = Dispatcher()

    def __init__(self, all_lessons, all_lessons_next, config, *args):
        self.all_lessons = all_lessons
        self.all_lessons_next = all_lessons_next
        self.config = config
        self.bot = Bot(token=telegram_config["token"])
        self.handler = self.dp.message()(self.handler)
        self.tasks = []

    async def handler(self, message):
        print("Start")
        task = asyncio.create_task(self.message_handler(message))
        print("Is running")

    async def message_handler(self, message):
        text = message.text
        user = message.from_user.id

        if self.config["logging"]:
            print(user if user not in self.config["contacts"] else self.config["contacts"][user])
            print(text)

        if text[0] == "/":
            await self.command_handler(message)
        else:
            typing = await message.answer("⌛️ Печатаю...")
            await typing.edit_text(gpt.curl(text))

    async def command_handler(self, message):
        text = message.text
        user = message.from_user.id
        if text == "/dz":
            output = (await self.dz(message))
            await message.answer(output, parse_mode="Markdown")

    async def dz(self, message):
        return auto_parse_les(self.all_lessons, self.all_lessons_next, -1, markdown=True)

    async def start(self):
        await self.bot.send_message(1667209703, "*К вашим услугам сэр.*", parse_mode="Markdown")
        await self.dp.start_polling(self.bot)

async def main():
    all_lessons, all_lessons_next = init()
    Bot = Telegram(all_lessons, all_lessons_next, telegram_config)
    await Bot.start()

    

if __name__ == "__main__":
    asyncio.run(main())