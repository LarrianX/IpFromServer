"""
Умный помощник использующий GPT.
Интерфейс взаимодействия осуществляется через такие мессенджеры, как Discord или Telegram, 
    а также доступна Telnet версия

"""
import elschool_api as els
import telegram_bot
import asyncio
import multiprocessing as mp
import time
from config import *

process_pool = []

def run_loop(function):
    asyncio.run(function())

def updater():
    global Bot
    while True:
        time.sleep(300)
        Bot.all_lessons, Bot.all_lessons_next = els.init()

def main():
    global Bot
    all_lessons, all_lessons_next = els.init()
    Bot = telegram_bot.Telegram(all_lessons, all_lessons_next, telegram_config)
    process1 = mp.Process(target=run_loop, args=(Bot.start,))
    process2 = mp.Process(target=updater)
    process_pool.append(process1)
    process_pool.append(process2)
    process1.start()
    process2.start()


if __name__ == "__main__":
    main()
