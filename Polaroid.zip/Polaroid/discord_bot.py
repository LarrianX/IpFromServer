import discord
import asyncio
from discord.ext import commands
from config import discord_config


class Discord:
    def __init__(self, all_lessons, all_lessons_next, config, *args):
        self.intents = discord.Intents.default()
        self.intents.message_content = True
        # self.bot = commands.Bot(command_prefix="#", intents=self.intents)
        self.bot = discord.Client(intents=self.intents)
        self.token = config["token"]
        self.on_message = self.bot.event(self.on_message)

    async def on_message(self, ctx):
        text = ctx.message.text
        user = ctx.message.author
        print("1223")

        await ctx.send("ыы")

    async def start(self):
        await self.bot.start(self.token)


def main():
    Bot = Discord(..., ..., discord_config)
    print(1)
    try:
        asyncio.run(Bot.start())
    except Exception as e:
        print(repr(e))

if __name__ == "__main__":
    main()