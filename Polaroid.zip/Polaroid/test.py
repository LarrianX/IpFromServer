rec = 0
def a():
    global rec
    rec += 1
    print(rec)
    if rec == 997:
        print("END")
        return
    a()

a()